This section will give you an overview of minimal system requirements for developing and running MonoGame Applications.

### Development
* Windows - 
* Linux - 1 GB Ram
* Mac - 

### Running MonoGame Application on specific Platform
* WindowsDX - DirectX 9.0c capable gpu
* WindowsGL - 
* Linux - 512 MB Ram
* Mac -
* Android - Android 4.2 or higher
* iOS -
* Windows Phone - Windows Phone 8 or higher

