This section will help you setup MonoGame on Platform of your choice. Please select the platform you wish to develop from:

 - Windows
 - [Mac](setting_up_monogame_mac.md)
 - [Linux](setting_up_monogame_linux.md)
 - [Building from source](setting_up_monogame_source.md)
